package com.intel.samples.contextsensingapiflow;

public class Settings {
    public static final String API_KEY      = "EmtmRGxbOmccu33AH5D2qqU4Us3Kay3D";
    public static final String SECRET       = "WAUhKoNLx0EsMbIn";
    public static final String REDIRECT_URI = "http://54.245.105.150/oauth2callback2.html";
}