/** Automatically generated file. DO NOT MODIFY */
package com.intel.samples.contextsensingapiflow;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}